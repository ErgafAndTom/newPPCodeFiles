import React from "react";
import "./LoaderStyles.css"

const Loader2 = () => {



    return (
        <div className="система">
            <div className="шар" id="шар1"></div>
            <div className="шар" id="шар2"></div>
            <div className="шар" id="шар3"></div>
        </div>
    );
};

export default Loader2;