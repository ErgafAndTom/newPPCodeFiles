import React from "react";
import {Materials} from "./materialsanddop/Materials";

export const AfterPrint = () => {
    return (
        <div>
            <Materials/>
        </div>
    )
}