import React from "react";
import {Format} from "./formatdrukview/Format";
// import {View} from "./formatdrukview/View";

export const Photo = () => {
    return (
        <div className="d-flex">
            <Format/>
            {/*<View/>*/}
        </div>
    )
}