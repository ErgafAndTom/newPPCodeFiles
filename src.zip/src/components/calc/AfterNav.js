import React from "react";
import {Route, Routes} from 'react-router-dom';
import {useSelector} from "react-redux";
import Loader from "./Loader";

const AfterNav = () => {
    const pricesIsLoading = useSelector(state => state.prices.pricesIsLoading);
    const pricesError = useSelector(state => state.prices.pricesError);
    const token = useSelector((state) => state.auth.token);

    if (pricesIsLoading) {
        return (
            <div>
                <Routes>
                    <Route path="/" element={<Loader/>} />
                    <Route path="/files" element={<Loader/>} />
                    <Route path="/createOrder" element={<Loader/>} />
                    <Route path="/login" element={<Loader/>} />
                    <Route path="/admin" element={<Loader/>} />
                    <Route path="/currentUser" element={<Loader/>} />
                </Routes>
            </div>
        )
    }
    if (pricesError) {
        return (
            <div>
                <Routes>
                    <Route path="/" element={<div>{pricesError}</div>} />
                    <Route path="/files" element={<div>{pricesError}</div>} />
                    <Route path="/createOrder" element={<div>{pricesError}</div>} />
                    <Route path="/login" element={<div>{pricesError}</div>} />
                    <Route path="/admin" element={<div>{pricesError}</div>} />
                    <Route path="/currentUser" element={<div>{pricesError}</div>} />
                </Routes>
            </div>
        )
    }
    return (
        <div>
            <Routes>
                {/*<Route path="/" element={<MainWindow/>} />*/}
                {/*<Route path="/" element={<Desktop/>} />*/}
                {/*<Route path="/files" element={<Files/>} />*/}
                {/*<Route path="/createOrder" element={<CreateOrder/>} />*/}
                {/*<Route path="/login" element={<Login/>} />*/}
                {/*<Route path="/Users" element={<UsersTable/>} />*/}
                {/*<Route path="/Stars" element={*/}
                {/*    <div>*/}
                {/*        <div style={{width: '100vw', height: '80vh'}}>*/}
                {/*            1*/}
                {/*        </div>*/}
                {/*    </div>*/}
                {/*}/>*/}

                {/*<Route exact path="/login">*/}
                {/*    {token ? <Redirect to="/profile" /> : <Login />}*/}
                {/*</Route>*/}

                {/*<Route path="/admin" element={<Admin/>} />*/}
                {/*<Route path="/currentUser" element={<Profile/>} />*/}

                {/*<Route path="/Orders" element={<Orders/>} />*/}
                {/*<Route path="/Orders" element={<CustomOrderTable/>} />*/}
                {/*<Route path="/Orders/:id" element={<NewUIArtem/>} />*/}

                {/*<Route path="/Desktop" element={<ClientPip/>} />*/}
                {/*<Route path="/Desktop" element={<NewUIArtem/>} />*/}
                {/*<Route path="/Desktop/:id" element={<NewUIArtem/>} />*/}

                {/*<Route path="/Cash" element={<CrmCash2/>} />*/}
                {/*<Route path="/Cash/:id" element={<CrmCash2/>} />*/}
                {/*<Route path="/Storage" element={<TableStorage name={"Склад"}/>} />*/}
                {/*<Route path="/Devices" element={<TableStorage name={"Devices"}/>} />*/}
                {/*<Route path="/Desktop" element={<Desktop/>} />*/}
                {/*<Route path="/Desktop" element={<NewUIArtem/>} />*/}
                {/*<Route path="/CashFull" element={<Kassa/>} />*/}
                {/*<Route path="/CashFull/:id" element={<Kassa/>} />*/}

                {/*<Route path="/CashFull" element={<CrmCash2/>} />*/}
                {/*<Route path="/CashFull/:id" element={<CrmCash2/>} />*/}

                {/*<Route path="/CashFull" element={<CrmCash3Full/>} />*/}
                {/*<Route path="/CashFull/:id" element={<CrmCash3Full/>} />*/}

                {/*<Route path="/products" element={<Main/>} />*/}
                {/*<Route path="/products/Sheet" element={<Sheet/>} />*/}
                {/*<Route path="/products/Sheetcut" element={<SheetCut/>} />*/}
                {/*<Route path="/products/Note" element={<Note/>} />*/}
                {/*<Route path="/products/Photo" element={<Photo/>} />*/}
                {/*<Route path="/products/FiguredProducts" element={<Note/>} />*/}
                {/*<Route path="/products/Wide" element={<Wide/>} />*/}
                {/*<Route path="/products/Plotter" element={<Plotter/>} />*/}

                {/*<Route path="/Main" element={<MainSite/>} />*/}
            </Routes>
        </div>
    );
};

export default AfterNav;