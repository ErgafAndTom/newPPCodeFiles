y// import React, {useEffect, useState} from "react";
// import styles from "../artemm/components/Component5.module.css";
//
// const Wwwwww = () => {
//
//     return (
//         <div>
//             <div className={styles.div1}>Розмір виробу</div>
//             <div className={styles.pickerTopLabel}>
//                 <div className={styles.placementArea}/>
//                 <div className={styles.fieldButton}/>
//                 <div className={styles.text}>Розмір</div>
//                 <div className={styles.chevron}>
//                     <img className={styles.shapeIcon} alt="" src="/shape.svg"/>
//                 </div>
//                 <div className={styles.cursorArea}/>
//                 <div className={styles.touchArea}/>
//                 <div className={styles.menu}>
//                     <div className={styles.placementArea1}/>
//                     <div className={styles.background}/>
//                     <div className={styles.hover}/>
//                     <div className={styles.menuItem}/>
//                     <div className={styles.home}>Home</div>
//                     <div className={styles.menuItem1}/>
//                     <div className={styles.documents}>Documents</div>
//                     <div className={styles.menuItem2}/>
//                     <div className={styles.gallery}>Gallery</div>
//                     <div className={styles.checkmark}>
//                         <img className={styles.shapeIcon1} alt="" src="/shape1.svg"/>
//                     </div>
//                 </div>
//                 <div className={styles.fieldButton1}/>
//                 <div className={styles.text1}>А4 (210 х 297 мм)</div>
//                 <div className={styles.icondropdownArrowsmall}>
//                     <img className={styles.maskIcon} alt="" src="/mask.svg"/>
//                 </div>
//             </div>
//             <div className={styles.div2}>
//                 <div className={styles.div3}/>
//                 <div className={styles.div4}>
//                     <span>{`210 `}</span>
//                     <span className={styles.span}>мм</span>
//                 </div>
//             </div>
//             <div className={styles.div5}>
//                 <div className={styles.div3}/>
//                 <div className={styles.div4}>
//                     <span>{`297 `}</span>
//                     <span className={styles.span}>мм</span>
//                 </div>
//             </div>
//             <div className={styles.div8}>х</div>
//         </div>
//     );
// }
//
// export default Wwwwww;