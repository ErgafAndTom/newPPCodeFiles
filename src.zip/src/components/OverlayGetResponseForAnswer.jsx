import Button from 'react-bootstrap/Button';
import {OverlayTrigger} from "react-bootstrap";
import {Tooltip} from "chart.js";

function OverlayGetResponseForAnswer({question, answerText}) {
    return (
        <OverlayTrigger
            placement="bottom"
            overlay={<Tooltip id="button-tooltip-2">{answerText}</Tooltip>}
        >
            {({ ref, ...triggerHandler }) => (
                <Button
                    variant="light"
                    {...triggerHandler}
                    className="d-inline-flex align-items-center"
                >
                    <span className="ms-1">{question}</span>
                </Button>
            )}
        </OverlayTrigger>
    );
}

export default OverlayGetResponseForAnswer;