import React from 'react';

const Home = () => {
    return (
        <div>
            <h2>Welcome to PrintPeaks</h2>
            <p>Your one-stop shop for all printing needs.</p>
        </div>
    );
}

export default Home;
